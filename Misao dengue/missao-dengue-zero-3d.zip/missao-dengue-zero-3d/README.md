# Missão Dengue Zero 3D

Jogo educativo 3D de combate ao Aedes aegypti, desenvolvido pela NEWPC Tecnologia para o Portal do Educador.

Voltado para o Ensino Fundamental, professores e campanhas municipais de saúde. Roda direto no navegador, em computador, tablet, celular e lousa digital, sem instalação.

## Como jogar
O aluno percorre 5 fases eliminando focos de água parada (pneus, vasos, caixas d'água, calhas, piscinas, tampinhas e outros), aprende uma dica de prevenção a cada foco e responde quizzes ao final de cada fase. A fase 4 é o duelo contra o Mosquito Vilão. Ao concluir as 5 fases, o aluno recebe o selo Agente Dengue Zero e um certificado imprimível.

Há um Modo Professor com ranking da turma e relatório para acompanhamento pedagógico.

## Arquivos
- `index.html` — versão padrão (carrega Three.js e fontes via internet)
- `index-offline.html` — versão autossuficiente, roda sem internet (Three.js embutido, fontes do sistema). Indicada para escolas com rede instável.

## Tecnologia
Arquivo único HTML/CSS/JavaScript, Three.js r128, cenários 3D procedurais, sem build e sem dependências de servidor. Progresso e ranking salvos localmente no dispositivo.

---
NEWPC Tecnologia · Portal do Educador
